<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Book Lovers</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div id="navbar">
            <div id="logobox">
                <img src="images/logo.png" alt="logo" id="logoimg">
            </div>
            <div id="navitems">
                <a href="index.php">Home</a>
                <a href="bookstore.php">Books</a>
            </div>
        </div>

        <div class="data">
            <p>Success</p>
            <a href="bookstore.php">Check the bookstore again for stock</a>
        </div>

        <div id="footer">
            <div id="address">
                <p>Booklovers Headquarter</p>
                <p>1079, Trafalgar Avenue</p>
                <p>Brampton, Ontario</p>
                <p>Canada, L7F 5G6</p>
            </div>
            
            <div id="copyright">
                <p>&#169; Copyright Booklovers. All rights Reserved.</p>
                <p>Akashdeep Singh</p>
            </div>
        </div>
    </body>
</html>