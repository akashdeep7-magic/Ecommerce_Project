CREATE TABLE authors(
	aid INT AUTO_INCREMENT,
    aname VARCHAR(255) NOT NULL,
    PRIMARY KEY(aid)
);

CREATE TABLE publishers(
	pid INT AUTO_INCREMENT,
    pname VARCHAR(255) NOT NULL,
    PRIMARY KEY(pid)
);

CREATE TABLE genre(
	gid INT AUTO_INCREMENT,
    gname VARCHAR(255) NOT NULL,
    PRIMARY KEY(gid)
);

CREATE TABLE bookInventory(
	bid INT AUTO_INCREMENT,
    bname VARCHAR(255) NOT NULL,
    bprice DECIMAL(10,2) NOT NULL,
    year INT NOT NULL,
    stock INT NOT NULL,
    aid INT NOT NULL,
    pid INT NOT NULL,
    gid INT NOT NULL,
    PRIMARY KEY(bid),
    FOREIGN KEY(aid) REFERENCES authors(aid),
    FOREIGN KEY(pid) REFERENCES publishers(pid),
    FOREIGN KEY(gid) REFERENCES genre(gid)
);

CREATE TABLE bookinventoryorder(
	order_id INT AUTO_INCREMENT,
    firstName VARCHAR(255) NOT NULL,
    lastName VARCHAR(255) NOT NULL,
    payment VARCHAR(255) NOT NULL,
    PRIMARY KEY(order_id)
);