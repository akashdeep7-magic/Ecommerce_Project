<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Book Lovers</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div id="navbar">
            <div id="logobox">
                <img src="images/logo.png" alt="logo" id="logoimg">
            </div>
            <div id="navitems">
                <a href="index.php">Home</a>
                <a href="bookstore.php">Books</a>
            </div>
        </div>

        <div class="inventory">
            <?php
                require('mysqli_connect.php');
        
                $query1 = "SELECT bid, bname, aname, pname, year, bprice, stock FROM authors
                JOIN bookinventory
                ON authors.aid=bookinventory.aid
                JOIN publishers
                ON bookinventory.pid=publishers.pid";
                
                $result1 = mysqli_query($connection, $query1);
                
                $num = mysqli_num_rows($result1);

                if($num>0) {
                    while($row = mysqli_fetch_array($result1, MYSQLI_ASSOC)){
                        ?>
                            <a href="checkout.php?id=<?php echo $row['bid']; ?>">
                            <br>Book : <?php echo $row['bname']; ?><br>
                            Author : <?php echo $row['aname']; ?><br>
                            Publisher : <?php echo $row['pname']; ?><br>
                            Published Year : <?php echo $row['year']; ?><br>
                            Price : $<?php echo $row['bprice']; ?><br>
                            Stock : <?php echo $row['stock']; ?></a><br>
                                
                        <?php
                        } 
                    mysqli_free_result($result1);
                    
                }else {
                    echo '<br>There are no books in the database.';
                }
                
                mysqli_close($connection);
            ?>
        </div>
        
        <div id="footer">
            <div id="address">
                <p>Booklovers Headquarter</p>
                <p>1079, Trafalgar Avenue</p>
                <p>Brampton, Ontario</p>
                <p>Canada, L7F 5G6</p>
            </div>
            
            <div id="copyright">
                <p>&#169; Copyright Booklovers. All rights Reserved.</p>
                <p>Akashdeep Singh</p>
            </div>
        </div>
    </body>
</html>