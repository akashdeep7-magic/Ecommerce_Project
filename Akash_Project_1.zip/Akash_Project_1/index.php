<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Book Lovers</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div id="navbar">
            <div id="logobox">
                <img src="images/logo.png" alt="logo" id="logoimg">
            </div>
            <div id="navitems">
                <a href="index.php">Home</a>
                <a href="bookstore.php">Books</a>
            </div>
        </div>

        <div id="banner">
            <img src="images/banner.jpg" alt="banner" id="bannerimg">
        </div>

        <div id="display">
            <div id="textbox">
                <p><i>Discover</i> your next book</p>
            </div>
            
            <div class="imgbox">
                <div class="imgholder">
                    <a href="bookstore.php"><img src="images/book1.jpg" alt="book1" height="300px" width="200px"></a>
                    <a href="bookstore.php"><img src="images/book2.jpg" alt="book2" height="300px" width="200px"></a>
                    <a href="bookstore.php"><img src="images/book3.jpg" alt="book3" height="300px" width="200px"></a>
                </div>
            </div>
        </div>
        
        <div id="footer">
            <div id="address">
                <p>Booklovers Headquarter</p>
                <p>1079, Trafalgar Avenue</p>
                <p>Brampton, Ontario</p>
                <p>Canada, L7F 5G6</p>
            </div>
            
            <div id="copyright">
                <p>&#169; Copyright Booklovers. All rights Reserved.</p>
                <p>Akashdeep Singh</p>
            </div>
        </div>
    </body>
</html>