<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Book Lovers</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div id="navbar">
            <div id="logobox">
                <img src="images/logo.png" alt="logo" id="logoimg">
            </div>
            <div id="navitems">
                <a href="index.php">Home</a>
                <a href="bookstore.php">Books</a>
            </div>
        </div>

        <div class="checkout">
           <div id="formbox">
           <form method="POST" action="checkout.php">
                <p>Firstname: <input type="text" name="fname" value="<?php if(isset($_POST['fname'])) echo $_POST['fname']; ?>"></p>
                <p>Lastname: <input type="text" name="lname" value="<?php if(isset($_POST['lname'])) echo $_POST['lname']; ?>"></p>
                <label>Payment Method:</label>
                <select name="payment">
                    <option value="">Select an option</option>
                    <option value="card">Credit/Debit Card</option>
                    <option value="cash">Cash</option>
                    <option value="cod">Cash on Delivery</option>
                </select>
                <p><input type="submit" value="Place Order" name="submit"></p>
            </form> 
            </div>
            <?php
            session_start();

            $queries = array();
            parse_str($_SERVER['QUERY_STRING'], $queries);

            require('mysqli_connect.php');
            if(isset($_GET['id'])){

                $id = $queries['id'];
                $query2 = "SELECT bid, bname, aname, pname, year, bprice, stock FROM authors
                JOIN bookinventory
                ON authors.aid=bookinventory.aid
                JOIN publishers
                ON bookinventory.pid=publishers.pid
                WHERE bid = $id";

                $result2 = $connection->query($query2);

                if ($result2->num_rows > 0) {
                    while($row = $result2->fetch_assoc()) {
                        $_SESSION['id']=$row['bid'];
                        $_SESSION["book"] = $row['bname'];
                        $_SESSION["author"] = $row['aname'];
                        $_SESSION["publisher"] = $row['pname'];
                        $_SESSION["pyear"] = $row['year'];
                        $_SESSION["price"] = $row['bprice'];
                        $_SESSION["stock"] = $row['stock'];
                    }
                }
            }

            $err = array();
            if($_SERVER["REQUEST_METHOD"] == "POST") {
                $firstname = $_POST['fname'];
                $lastname = $_POST['lname'];
                $paymentM = $_POST['payment'];
                $id= $_SESSION['id'];

                if(!empty($_POST['$firstname']) || strlen($firstname) == 0){
                    array_push($err, "Please enter your firstname.<br>");
                }else {
                    $firstname = filter_var($_POST['fname'], FILTER_SANITIZE_STRING);
                }

                if(!empty($_POST['$lastname']) || strlen($lastname) == 0){
                    array_push($err, "Please enter your lastname.<br>");
                }else {
                    $lastname = filter_var($_POST['lname'], FILTER_SANITIZE_STRING);
                }

                if(!empty($_POST['$paymentM']) || strlen($paymentM) == 0){
                    array_push($err, "Please select one payment method.<br>");
                }else {
                    $paymentM = filter_var($_POST['payment'], FILTER_SANITIZE_STRING);
                }

                if(empty($err))
                {
                    $query3 = "INSERT INTO bookinventoryorder (firstName, lastName, payment)
                    VALUES ('$_POST[fname]', '$_POST[lname]', '$_POST[payment]')";

                    $result3 = mysqli_query($connection, $query3);

                    $sql = "SELECT * FROM bookinventory WHERE bid = $id";
                    $query4 = mysqli_query($connection,$sql) or die( mysqli_error($connection));
                    $result4 = mysqli_fetch_array($query4);
                    $stockval = $result4['stock'];

                    $stockupdated = $stockval - 1;

                    $newstock = mysqli_query($connection,"UPDATE bookinventory SET stock = '$stockupdated' WHERE bid = $id");
                    
                    if($result3 || $newstock)
                    {
                        header("Location: success.php");
                    }
                    else
                    {
                        echo "Order not placed";
                    }

                } else {
                    foreach($err as $e) {
                        echo $e, '<br>';
                    }
                }
            }
            mysqli_close($connection);
        ?>
        </div>
        
        <div id="footer">
            <div id="address">
                <p>Booklovers Headquarter</p>
                <p>1079, Trafalgar Avenue</p>
                <p>Brampton, Ontario</p>
                <p>Canada, L7F 5G6</p>
            </div>
            
            <div id="copyright">
                <p>&#169; Copyright Booklovers. All rights Reserved.</p>
                <p>Akashdeep Singh</p>
            </div>
        </div>
    </body>
</html>