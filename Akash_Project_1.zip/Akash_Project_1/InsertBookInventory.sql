INSERT INTO genre (gname)
VALUES ('Programming/Scripting'),('Operating System'),('Computer Science');

INSERT INTO authors(aname)
VALUES ('Rodrigo Branas'),('Mark Lutz & David Ascher'),('Etienne Savard'),('Cody Lindley'),('Lieven and Stephen'),('D.C. Hankerson');

INSERT INTO publishers(pname)
VALUES ('Packt Publishing'),('Agiledroid'),('O’Reilly Media, Inc.'),('Cambridge University Press'),('Springer-Verlag GmbH');

INSERT INTO bookinventory(bname, bprice, year, stock, aid, pid, gid)
VALUES ('AngularJS Essentials','10.64','2014','5','1','1','1'),
('Learning Python','31.76','2015','8','2','1','1'),
('Agile Android Software Development','17.33','2016','3','3','2','2'),
('JavaScript Enlightenment','15.99','2013','14','4','3','2'),
('Convex Optimization','158.99','2004','10','5','4','3'),
('Coding Theory and Cryptography','124.36','1999','2','6','5','3');

INSERT INTO users(uid, user_fname, user_lname, email, mobile, add_id, cid)
VALUES 

INSERT INTO sales(sid, sale_date, quantity, sales_price, bid, uid)
VALUES 